import React from 'react';
import Image from 'next/image';

export const CampaignUpdates = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">Campaign Updates</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Update Cards */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="relative h-48">
              <Image
                src="/images/gaza/Gaza-Medical-Aid.jpg"
                alt="Medical Aid Distribution"
                fill
                className="object-cover"
              />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-2">Medical Aid Distribution</h3>
              <p className="text-gray-600">
                Successfully delivered essential medical supplies to hospitals in Gaza, 
                supporting thousands of patients in need.
              </p>
              <p className="text-sm text-gray-500 mt-4">March 15, 2025</p>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="relative h-48">
              <Image
                src="/images/gaza/Gaza-Food.jpg"
                alt="Food Distribution"
                fill
                className="object-cover"
              />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-2">Emergency Food Distribution</h3>
              <p className="text-gray-600">
                Distributed food parcels to over 25,000 families in Deir Al-Balah and Rafah areas.
              </p>
              <p className="text-sm text-gray-500 mt-4">March 10, 2025</p>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="relative h-48">
              <Image
                src="/images/gaza/Gaza-Clean-Water-1-.jpg"
                alt="Water Well Project"
                fill
                className="object-cover"
              />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-2">Water Well Rehabilitation</h3>
              <p className="text-gray-600">
                Completed rehabilitation of water wells in Al Khair and Al Naser, 
                providing clean water to 50,000 residents.
              </p>
              <p className="text-sm text-gray-500 mt-4">March 5, 2025</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}; 