const { PrismaClient } = require('@prisma/client');
const { hash } = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  try {
    // Delete existing admin user if exists
    await prisma.user.deleteMany({
      where: {
        email: 'admin@muslimhelpgaza.com'
      }
    });

    // Create admin user with new password
    const password = await hash('Admin@123', 12);
    const admin = await prisma.user.create({
      data: {
        name: 'Admin',
        email: 'admin@muslimhelpgaza.com',
        password: password,
        role: 'ADMIN',
      },
    });

    console.log('Admin user created successfully');

    // Create default payment settings
    await prisma.paymentSettings.upsert({
      where: { id: 'default' },
      update: {},
      create: {
        id: 'default',
        currencies: 'USD',
        defaultCurrency: 'USD',
      },
    });

    // Create default language
    await prisma.language.upsert({
      where: { code: 'en' },
      update: {},
      create: {
        code: 'en',
        name: 'English',
        nativeName: 'English',
        direction: 'ltr',
        isDefault: true,
        isActive: true,
      },
    });

    console.log('Setup completed successfully!');
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main(); 