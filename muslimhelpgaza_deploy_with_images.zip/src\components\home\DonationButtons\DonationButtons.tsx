import React from 'react';
import Image from 'next/image';

export const DonationButtons = () => {
  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-4 justify-center mb-8">
        <a
          href="/donate"
          className="inline-flex justify-center items-center px-8 py-4 text-xl font-bold text-white bg-red-600 rounded-full hover:bg-red-700 transition-colors"
        >
          DONATE NOW
        </a>
        <a
          href="/zakat"
          className="inline-flex justify-center items-center px-8 py-4 text-xl font-bold text-[#1E40AF] bg-white rounded-full hover:bg-gray-100 transition-colors"
        >
          GIVE ZAKAT
        </a>
      </div>

      {/* Payment Methods */}
      <div className="flex justify-center items-center">
        <Image
          src="/images/payments/payments-no-paypal.png"
          alt="Payment Methods Accepted: Visa, Mastercard, American Express, Apple Pay, Google Pay"
          width={250}
          height={40}
          className="opacity-90"
          priority
        />
      </div>

      {/* Certification Info */}
      <div className="text-center mt-6 text-white text-sm">
        <p className="mb-2">
          <i className="fas fa-check-circle mr-2"></i>
          <strong>Registered Canadian & U.S. Nonprofit</strong>
        </p>
        <p className="mb-4">
          <i className="fas fa-check-circle mr-2"></i>
          <strong>100% Zakat-Eligible</strong>
        </p>
        <p className="text-xs opacity-80">
          Humaniti's charitable registration number in Canada is 719676926RR0001CRA, and in the USA they are a 501(c)(3) U.S. Nonprofit with Tax ID 92-3079413.
        </p>
      </div>
    </div>
  );
}; 