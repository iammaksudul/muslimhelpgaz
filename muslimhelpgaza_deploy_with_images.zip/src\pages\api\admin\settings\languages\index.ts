import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  if (!session || session.user.role !== 'ADMIN') {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (req.method === 'GET') {
    try {
      const languages = await prisma.language.findMany({
        orderBy: {
          code: 'asc',
        },
      });

      return res.status(200).json(languages);
    } catch (error) {
      console.error('Error fetching languages:', error);
      return res.status(500).json({ error: 'Failed to fetch languages' });
    }
  }

  if (req.method === 'POST') {
    try {
      const { code, name, nativeName, direction, isActive } = req.body;

      if (!code || !name || !nativeName) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      if (direction !== 'ltr' && direction !== 'rtl') {
        return res.status(400).json({ error: 'Invalid direction value' });
      }

      const existingLanguage = await prisma.language.findUnique({
        where: { code },
      });

      if (existingLanguage) {
        return res.status(400).json({ error: 'Language already exists' });
      }

      // If this is the first language, make it default
      const languageCount = await prisma.language.count();
      const isDefault = languageCount === 0;

      const language = await prisma.language.create({
        data: {
          code,
          name,
          nativeName,
          direction,
          isActive: isActive ?? true,
          isDefault,
        },
      });

      return res.status(201).json(language);
    } catch (error) {
      console.error('Error creating language:', error);
      return res.status(500).json({ error: 'Failed to create language' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
} 