import { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Only allow in development
  if (process.env.NODE_ENV !== 'development') {
    return res.status(404).json({ error: 'Not found' });
  }

  try {
    // Check if admin user exists
    const adminUser = await prisma.user.findUnique({
      where: { email: 'admin@muslimhelpgaza.com' },
      select: {
        id: true,
        email: true,
        role: true,
        // Don't select password for security
      },
    });

    return res.status(200).json({
      adminUserExists: !!adminUser,
      adminUser,
    });
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).json({ error: 'Database error' });
  } finally {
    await prisma.$disconnect();
  }
} 