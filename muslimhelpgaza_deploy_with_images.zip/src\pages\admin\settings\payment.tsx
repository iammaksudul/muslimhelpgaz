import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/router';
import AdminLayout from '@/components/admin/AdminLayout';
import { Switch } from '@headlessui/react';
import { toast } from 'react-hot-toast';

interface PaymentSettings {
  id: number;
  stripeEnabled: boolean;
  stripePublicKey: string | null;
  stripeSecretKey: string | null;
  paypalEnabled: boolean;
  paypalClientId: string | null;
  paypalSecret: string | null;
  bKashEnabled: boolean;
  bKashNumber: string | null;
  rocketEnabled: boolean;
  rocketNumber: string | null;
  currencies: string[];
  defaultCurrency: string;
}

const AVAILABLE_CURRENCIES = [
  { code: 'USD', name: 'US Dollar' },
  { code: 'EUR', name: 'Euro' },
  { code: 'GBP', name: 'British Pound' },
  { code: 'AUD', name: 'Australian Dollar' },
  { code: 'CAD', name: 'Canadian Dollar' },
  { code: 'JPY', name: 'Japanese Yen' },
  { code: 'INR', name: 'Indian Rupee' },
  { code: 'BDT', name: 'Bangladeshi Taka' },
  { code: 'AED', name: 'UAE Dirham' },
  { code: 'SAR', name: 'Saudi Riyal' },
];

export default function PaymentSettingsPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const [settings, setSettings] = useState<PaymentSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [selectedCurrencies, setSelectedCurrencies] = useState<string[]>([]);
  const [defaultCurrency, setDefaultCurrency] = useState('USD');

  useEffect(() => {
    if (session?.user.role !== 'ADMIN') {
      router.push('/');
      return;
    }

    fetchSettings();
  }, [session]);

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/admin/settings/payment');
      if (!response.ok) throw new Error('Failed to fetch settings');
      const data = await response.json();
      setSettings(data);
      setSelectedCurrencies(data.currencies || ['USD']);
      setDefaultCurrency(data.defaultCurrency || 'USD');
    } catch (error) {
      console.error('Error fetching settings:', error);
      toast.error('Failed to load payment settings');
    } finally {
      setLoading(false);
    }
  };

  const handleToggle = async (field: keyof PaymentSettings) => {
    if (!settings) return;

    setSaving(true);
    try {
      const updatedSettings = {
        ...settings,
        [field]: !settings[field],
      };

      const response = await fetch('/api/admin/settings/payment', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedSettings),
      });

      if (!response.ok) throw new Error('Failed to update settings');
      
      setSettings(updatedSettings);
      toast.success('Settings updated successfully');
    } catch (error) {
      console.error('Error updating settings:', error);
      toast.error('Failed to update settings');
    } finally {
      setSaving(false);
    }
  };

  const handleCurrencyToggle = (currencyCode: string) => {
    if (selectedCurrencies.includes(currencyCode)) {
      if (currencyCode === defaultCurrency) {
        toast.error('Cannot remove default currency');
        return;
      }
      setSelectedCurrencies(selectedCurrencies.filter(c => c !== currencyCode));
    } else {
      setSelectedCurrencies([...selectedCurrencies, currencyCode]);
    }
  };

  const handleDefaultCurrencyChange = (currencyCode: string) => {
    setDefaultCurrency(currencyCode);
  };

  const handleSaveCurrencies = async () => {
    if (!settings) return;

    setSaving(true);
    try {
      const updatedSettings = {
        ...settings,
        currencies: selectedCurrencies,
        defaultCurrency,
      };

      const response = await fetch('/api/admin/settings/payment', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedSettings),
      });

      if (!response.ok) throw new Error('Failed to update currency settings');
      
      setSettings(updatedSettings);
      toast.success('Currency settings updated successfully');
    } catch (error) {
      console.error('Error updating currency settings:', error);
      toast.error('Failed to update currency settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="max-w-4xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Payment Settings</h1>
        
        <div className="bg-white shadow rounded-lg p-6 space-y-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Payment Methods</h2>
          
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium text-gray-900">Stripe Payments</h3>
              <p className="text-sm text-gray-500">Enable or disable Stripe payment processing</p>
            </div>
            <Switch
              checked={settings?.stripeEnabled || false}
              onChange={() => handleToggle('stripeEnabled')}
              className={`${
                settings?.stripeEnabled ? 'bg-primary' : 'bg-gray-200'
              } relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2`}
              disabled={saving}
            >
              <span
                className={`${
                  settings?.stripeEnabled ? 'translate-x-6' : 'translate-x-1'
                } inline-block h-4 w-4 transform rounded-full bg-white transition-transform`}
              />
            </Switch>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium text-gray-900">PayPal Payments</h3>
              <p className="text-sm text-gray-500">Enable or disable PayPal payment processing</p>
            </div>
            <Switch
              checked={settings?.paypalEnabled || false}
              onChange={() => handleToggle('paypalEnabled')}
              className={`${
                settings?.paypalEnabled ? 'bg-primary' : 'bg-gray-200'
              } relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2`}
              disabled={saving}
            >
              <span
                className={`${
                  settings?.paypalEnabled ? 'translate-x-6' : 'translate-x-1'
                } inline-block h-4 w-4 transform rounded-full bg-white transition-transform`}
              />
            </Switch>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium text-gray-900">bKash Payments</h3>
              <p className="text-sm text-gray-500">Enable or disable bKash payment processing</p>
            </div>
            <Switch
              checked={settings?.bKashEnabled || false}
              onChange={() => handleToggle('bKashEnabled')}
              className={`${
                settings?.bKashEnabled ? 'bg-primary' : 'bg-gray-200'
              } relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2`}
              disabled={saving}
            >
              <span
                className={`${
                  settings?.bKashEnabled ? 'translate-x-6' : 'translate-x-1'
                } inline-block h-4 w-4 transform rounded-full bg-white transition-transform`}
              />
            </Switch>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium text-gray-900">Rocket Payments</h3>
              <p className="text-sm text-gray-500">Enable or disable Rocket payment processing</p>
            </div>
            <Switch
              checked={settings?.rocketEnabled || false}
              onChange={() => handleToggle('rocketEnabled')}
              className={`${
                settings?.rocketEnabled ? 'bg-primary' : 'bg-gray-200'
              } relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2`}
              disabled={saving}
            >
              <span
                className={`${
                  settings?.rocketEnabled ? 'translate-x-6' : 'translate-x-1'
                } inline-block h-4 w-4 transform rounded-full bg-white transition-transform`}
              />
            </Switch>
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-6 space-y-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Currency Settings</h2>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Default Currency
            </label>
            <select
              value={defaultCurrency}
              onChange={(e) => handleDefaultCurrencyChange(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
            >
              {AVAILABLE_CURRENCIES.map((currency) => (
                <option key={currency.code} value={currency.code}>
                  {currency.name} ({currency.code})
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Available Currencies
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {AVAILABLE_CURRENCIES.map((currency) => (
                <div key={currency.code} className="flex items-center">
                  <input
                    type="checkbox"
                    id={`currency-${currency.code}`}
                    checked={selectedCurrencies.includes(currency.code)}
                    onChange={() => handleCurrencyToggle(currency.code)}
                    className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                  />
                  <label htmlFor={`currency-${currency.code}`} className="ml-2 text-sm text-gray-700">
                    {currency.name} ({currency.code})
                  </label>
                </div>
              ))}
            </div>
          </div>
          
          <div className="pt-4">
            <button
              onClick={handleSaveCurrencies}
              disabled={saving}
              className="w-full px-4 py-2 bg-primary text-white rounded hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save Currency Settings'}
            </button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
} 