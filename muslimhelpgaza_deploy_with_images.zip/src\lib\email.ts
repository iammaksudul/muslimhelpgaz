import nodemailer from 'nodemailer';
import { formatCurrency } from './utils';

// Configure nodemailer with environment variables
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export async function sendWelcomeEmail(email: string, password: string) {
  const mailOptions = {
    from: process.env.SMTP_FROM,
    to: email,
    subject: 'Welcome to Muslim Help Gaza',
    html: `
      <h1>Welcome to Muslim Help Gaza</h1>
      <p>Thank you for joining our platform. Here are your login credentials:</p>
      <p><strong>Email:</strong> ${email}</p>
      <p><strong>Password:</strong> ${password}</p>
      <p>Please change your password after your first login.</p>
      <p>Best regards,<br>Muslim Help Gaza Team</p>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending welcome email:', error);
    throw error;
  }
}

export async function sendDonationConfirmationEmail(
  email: string,
  name: string,
  amount: number,
  currency: string,
  isMonthly: boolean,
  donationId: string
) {
  const formattedAmount = formatCurrency(amount, currency);
  const donationType = isMonthly ? 'Monthly' : 'One-time';

  const mailOptions = {
    from: process.env.SMTP_FROM,
    to: email,
    subject: 'Thank You for Your Donation',
    html: `
      <h1>Thank You for Your Donation</h1>
      <p>Dear ${name},</p>
      <p>Thank you for your generous ${donationType.toLowerCase()} donation of ${formattedAmount}.</p>
      <p>Donation Details:</p>
      <ul>
        <li>Donation ID: ${donationId}</li>
        <li>Amount: ${formattedAmount}</li>
        <li>Type: ${donationType}</li>
      </ul>
      <p>Your support helps us make a difference in Gaza.</p>
      <p>Best regards,<br>Muslim Help Gaza Team</p>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending donation confirmation email:', error);
    throw error;
  }
} 