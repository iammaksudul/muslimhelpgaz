import { IconType } from 'react-icons';
import { FiHome, FiDollarSign, FiFileText, FiUsers, FiSettings, FiLogOut, FiImage } from 'react-icons/fi';
import { MdPayment, MdPending, MdError } from 'react-icons/md';
import { BiReceipt } from 'react-icons/bi';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { signOut } from 'next-auth/react';
import { useState } from 'react';

interface MenuItem {
  name: string;
  href: string;
  icon: IconType;
  subItems?: MenuItem[];
}

const menuItems: MenuItem[] = [
  {
    name: 'Dashboard',
    href: '/admin',
    icon: FiHome
  },
  {
    name: 'Payments',
    href: '/admin/payments',
    icon: FiDollarSign,
    subItems: [
      {
        name: 'All Payments',
        href: '/admin/payments',
        icon: MdPayment
      },
      {
        name: 'Invoices',
        href: '/admin/payments/invoices',
        icon: BiReceipt
      },
      {
        name: 'Currency Management',
        href: '/admin/payments/currency',
        icon: FiDollarSign
      }
    ]
  },
  {
    name: 'Content',
    href: '/admin/content',
    icon: FiFileText,
    subItems: [
      {
        name: 'Pages',
        href: '/admin/content/pages',
        icon: FiFileText
      },
      {
        name: 'Media',
        href: '/admin/content/media',
        icon: FiImage
      }
    ]
  },
  {
    name: 'Users',
    href: '/admin/users',
    icon: FiUsers,
    subItems: [
      {
        name: 'All Users',
        href: '/admin/users',
        icon: FiUsers
      },
      {
        name: 'Staff',
        href: '/admin/users/staff',
        icon: FiUsers
      }
    ]
  },
  {
    name: 'Settings',
    href: '/admin/settings',
    icon: FiSettings,
    subItems: [
      {
        name: 'General',
        href: '/admin/settings',
        icon: FiSettings
      },
      {
        name: 'Payment',
        href: '/admin/settings/payment',
        icon: FiDollarSign
      },
      {
        name: 'Language',
        href: '/admin/settings/language',
        icon: FiFileText
      }
    ]
  }
];

export default function AdminSidebar() {
  const router = useRouter();
  const [expandedItems, setExpandedItems] = useState<string[]>([]);

  const toggleSubMenu = (itemName: string) => {
    setExpandedItems(prev => 
      prev.includes(itemName) 
        ? prev.filter(item => item !== itemName)
        : [...prev, itemName]
    );
  };

  const isActive = (href: string) => router.pathname === href;
  const isExpanded = (name: string) => expandedItems.includes(name);

  const renderMenuItem = (item: MenuItem, level = 0) => {
    const hasSubItems = item.subItems && item.subItems.length > 0;
    const isItemActive = isActive(item.href);
    const isItemExpanded = isExpanded(item.name);

    return (
      <div key={item.href} className="w-full">
        <button
          onClick={() => hasSubItems ? toggleSubMenu(item.name) : router.push(item.href)}
          className={`w-full flex items-center px-4 py-2 text-sm transition-colors duration-200 ${
            isItemActive ? 'bg-gray-800 text-white' : 'text-gray-400 hover:text-white hover:bg-gray-800'
          }`}
          style={{ paddingLeft: `${level * 1}rem` }}
        >
          <item.icon className="w-5 h-5 mr-2" />
          <span>{item.name}</span>
          {hasSubItems && (
            <span className={`ml-auto transform transition-transform duration-200 ${isItemExpanded ? 'rotate-180' : ''}`}>
              ▼
            </span>
          )}
        </button>
        {hasSubItems && isItemExpanded && (
          <div className="bg-gray-900">
            {item.subItems.map(subItem => renderMenuItem(subItem, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="h-full w-64 bg-gray-900 text-white flex flex-col">
      <div className="p-4 border-b border-gray-800">
        <h1 className="text-xl font-bold">Admin Panel</h1>
      </div>
      <nav className="flex-1 overflow-y-auto">
        <div className="py-4">
          {menuItems.map(item => renderMenuItem(item))}
        </div>
      </nav>
      <button
        onClick={() => signOut()}
        className="p-4 border-t border-gray-800 flex items-center text-gray-400 hover:text-white hover:bg-gray-800 transition-colors duration-200"
      >
        <FiLogOut className="w-5 h-5 mr-2" />
        <span>Sign Out</span>
      </button>
    </div>
  );
} 