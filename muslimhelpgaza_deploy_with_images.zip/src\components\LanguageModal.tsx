import { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { FiX } from 'react-icons/fi';

interface Language {
  code: string;
  name: string;
  nativeName: string;
  isDefault: boolean;
  isActive: boolean;
  direction: 'ltr' | 'rtl';
}

interface LanguageModalProps {
  isOpen: boolean;
  onClose: () => void;
  language?: Language | null;
}

type FormData = {
  code: string;
  name: string;
  nativeName: string;
  direction: 'ltr' | 'rtl';
  isActive: boolean;
};

export default function LanguageModal({ isOpen, onClose, language }: LanguageModalProps) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState<FormData>({
    code: '',
    name: '',
    nativeName: '',
    direction: 'ltr',
    isActive: true,
  });
  const [error, setError] = useState('');

  useEffect(() => {
    if (language) {
      setFormData({
        code: language.code,
        name: language.name,
        nativeName: language.nativeName,
        direction: language.direction,
        isActive: language.isActive,
      });
    } else {
      setFormData({
        code: '',
        name: '',
        nativeName: '',
        direction: 'ltr',
        isActive: true,
      });
    }
  }, [language]);

  const mutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const url = language
        ? `/api/admin/settings/languages/${language.code}`
        : '/api/admin/settings/languages';
      const method = language ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Something went wrong');
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['languages'] });
      onClose();
    },
    onError: (error: Error) => {
      setError(error.message);
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!formData.code || !formData.name || !formData.nativeName) {
      setError('Please fill in all required fields');
      return;
    }

    mutation.mutate(formData);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">
            {language ? 'Edit Language' : 'Add Language'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <FiX className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Language Code
              </label>
              <input
                type="text"
                value={formData.code}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, code: e.target.value.toLowerCase() }))
                }
                disabled={!!language}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 disabled:bg-gray-100"
                placeholder="e.g., en"
                maxLength={2}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Language Name (English)
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, name: e.target.value }))
                }
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="e.g., English"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Native Name
              </label>
              <input
                type="text"
                value={formData.nativeName}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, nativeName: e.target.value }))
                }
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="e.g., English"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Text Direction
              </label>
              <select
                value={formData.direction}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, direction: e.target.value as 'ltr' | 'rtl' }))
                }
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="ltr">Left to Right (LTR)</option>
                <option value="rtl">Right to Left (RTL)</option>
              </select>
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="isActive"
                checked={formData.isActive}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, isActive: e.target.checked }))
                }
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="isActive" className="ml-2 block text-sm text-gray-900">
                Active
              </label>
            </div>

            {error && (
              <p className="text-sm text-red-600">{error}</p>
            )}

            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={mutation.isPending}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md disabled:opacity-50"
              >
                {mutation.isPending ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
} 