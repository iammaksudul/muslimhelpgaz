import React from 'react';
import Image from 'next/image';
import Link from 'next/link';

export const Footer = () => {
  return (
    <footer className="bg-[#2d2d2d] py-5 px-10">
      <div className="container mx-auto">
        <div className="flex flex-col items-center">
          {/* Donate Button */}
          <div className="mb-8">
            <Link
              href="https://donor.muslimi.com/-/XPBDJYTW"
              className="inline-block bg-red-600 text-white text-2xl font-bold py-4 px-16 rounded-full hover:bg-red-700 transition-colors"
            >
              DONATE NOW
            </Link>
          </div>

          {/* Logo */}
          <div className="mb-4">
            <Image
              src="/images/logo/muslimi-white-logo.png"
              alt="Muslimi Logo"
              width={200}
              height={60}
              className="mx-auto"
            />
          </div>

          {/* Copyright */}
          <div className="mb-4">
            <p className="text-center text-white/80 text-base">
              All Rights Reserved © 2024 Muslimi
            </p>
          </div>

          {/* Navigation Links */}
          <nav className="flex flex-wrap justify-center gap-6">
            <Link
              href="https://muslimi.com/privacy-policy/"
              target="_blank"
              className="text-white/80 hover:text-white text-base font-bold"
            >
              Privacy Policy
            </Link>
            <Link
              href="https://www.facebook.com/muslimi.official"
              target="_blank"
              className="text-white/80 hover:text-white text-base font-bold"
            >
              Facebook
            </Link>
            <Link
              href="https://www.instagram.com/muslimi.official/"
              target="_blank"
              className="text-white/80 hover:text-white text-base font-bold"
            >
              Instagram
            </Link>
            <Link
              href="#"
              className="text-white/80 hover:text-white text-base font-bold"
            >
              About Us
            </Link>
            <Link
              href="#"
              className="text-white/80 hover:text-white text-base font-bold"
            >
              Resources
            </Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}; 