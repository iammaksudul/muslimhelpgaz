import axios from 'axios';

interface PaymentDetails {
  amount: number;
  currency: string;
  isRecurring: boolean;
  email?: string;
  name?: string;
}

interface PaymentResponse {
  success: boolean;
  transactionId?: string;
  error?: string;
}

const EXCHANGE_RATES = {
  USD: 1,
  EUR: 0.85,
  GBP: 0.73,
  CAD: 1.25,
};

export const PaymentService = {
  convertCurrency: (amount: number, from: string, to: string = 'USD'): number => {
    const fromRate = EXCHANGE_RATES[from as keyof typeof EXCHANGE_RATES];
    const toRate = EXCHANGE_RATES[to as keyof typeof EXCHANGE_RATES];
    return (amount / fromRate) * toRate;
  },

  formatAmount: (amount: number, currency: string): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
    }).format(amount);
  },

  processPayment: async (details: PaymentDetails): Promise<PaymentResponse> => {
    try {
      // TODO: Replace with actual payment gateway integration
      const response = await axios.post('/api/process-payment', details);
      
      return {
        success: true,
        transactionId: response.data.transactionId,
      };
    } catch (error) {
      return {
        success: false,
        error: 'Payment processing failed. Please try again.',
      };
    }
  },

  validatePaymentDetails: (details: PaymentDetails): { valid: boolean; errors: string[] } => {
    const errors: string[] = [];

    if (!details.amount || details.amount <= 0) {
      errors.push('Please enter a valid amount');
    }

    if (!Object.keys(EXCHANGE_RATES).includes(details.currency)) {
      errors.push('Invalid currency selected');
    }

    if (details.email && !details.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      errors.push('Please enter a valid email address');
    }

    return {
      valid: errors.length === 0,
      errors,
    };
  },
}; 