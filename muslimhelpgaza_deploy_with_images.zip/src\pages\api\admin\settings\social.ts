import { NextApiRequest, NextApiResponse } from 'next';
import { getSession } from 'next-auth/react';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const session = await getSession({ req });

  if (!session || session.user?.role !== 'ADMIN') {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  if (req.method === 'GET') {
    try {
      const socialLinks = await prisma.socialLink.findMany({
        orderBy: { platform: 'asc' },
      });
      res.json(socialLinks);
    } catch (error) {
      console.error('Error fetching social links:', error);
      res.status(500).json({ message: 'Failed to fetch social links' });
    }
  } else if (req.method === 'PUT') {
    try {
      const { links } = req.body;

      // Delete existing links
      await prisma.socialLink.deleteMany();

      // Create new links
      await prisma.socialLink.createMany({
        data: links.map((link: any) => ({
          platform: link.platform,
          url: link.url,
          icon: link.icon,
        })),
      });

      res.json({ message: 'Social links updated successfully' });
    } catch (error) {
      console.error('Error updating social links:', error);
      res.status(500).json({ message: 'Failed to update social links' });
    }
  } else {
    res.setHeader('Allow', ['GET', 'PUT']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
} 