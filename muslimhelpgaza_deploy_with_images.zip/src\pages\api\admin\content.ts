import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]';
import prisma from '@/lib/prisma';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const session = await getServerSession(req, res, authOptions);

  if (!session || session.user.role !== 'ADMIN') {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (req.method === 'GET') {
    try {
      const content = await prisma.content.findFirst();
      return res.status(200).json(content || {});
    } catch (error) {
      console.error('Error fetching content:', error);
      return res.status(500).json({ error: 'Failed to fetch content' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const {
        heroTitle,
        heroSubtitle,
        aboutTitle,
        aboutContent,
        missionTitle,
        missionContent,
        impactTitle,
        impactContent,
        contactTitle,
        contactContent,
        footerText,
      } = req.body;

      const content = await prisma.content.upsert({
        where: { id: 1 },
        update: {
          heroTitle,
          heroSubtitle,
          aboutTitle,
          aboutContent,
          missionTitle,
          missionContent,
          impactTitle,
          impactContent,
          contactTitle,
          contactContent,
          footerText,
        },
        create: {
          id: 1,
          heroTitle,
          heroSubtitle,
          aboutTitle,
          aboutContent,
          missionTitle,
          missionContent,
          impactTitle,
          impactContent,
          contactTitle,
          contactContent,
          footerText,
        },
      });

      return res.status(200).json(content);
    } catch (error) {
      console.error('Error updating content:', error);
      return res.status(500).json({ error: 'Failed to update content' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
} 