# Muslim Help Gaza - Donation Platform

A modern, responsive donation platform built with Next.js to support humanitarian aid in Gaza.

## Developer
- **Developer**: Kh Maksudul Alam
- **GitHub**: [@iammaksudul](https://github.com/iammaksudul)
- **Provider**: Let's Encode

## Features
- 🌐 Responsive design for all devices
- 💳 Secure payment processing
- 📊 Real-time donation tracking
- 👤 User account management
- 📧 Email notifications
- 🔒 Admin dashboard with content management
- 🎨 Modern UI with animations
- 📱 Mobile-first approach
- 🌍 Multi-language support
- 📁 File upload & management

## Quick Installation

```bash
git clone https://github.com/yourusername/muslimhelpgaza.git && cd muslimhelpgaza && npm install
```

## Manual Installation

### Prerequisites
- Node.js 14+ 
- MariaDB (recommended) or MySQL
- npm or yarn

### Environment Setup
1. Clone the repository:
```bash
git clone https://github.com/yourusername/muslimhelpgaza.git
cd muslimhelpgaza
```

2. Install dependencies:
```bash
npm install
```

3. Create and configure `.env` file:
```env
DATABASE_URL="mysql://username:password@localhost:3306/database_name"
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-secure-secret-key"
NODE_ENV="development"
```

4. Initialize database:
```bash
npx prisma generate
npx prisma db push
node setup.js
```

5. Start the development server:
```bash
npm run dev
```

## Admin Access
After setup, you can login with these credentials:
- Email: admin@muslimhelpgaza.com
- Password: Admin@123

## Dependencies

### Core Dependencies
- next: ^14.1.0
- react: ^18.2.0
- react-dom: ^18.2.0
- typescript: ^5.0.0

### Database & Authentication
- @prisma/client: ^5.22.0
- next-auth: ^4.24.0
- bcryptjs: ^2.4.3

### UI & Styling
- @headlessui/react: ^1.7.0
- @heroicons/react: ^2.1.0
- tailwindcss: ^3.4.0
- react-icons: ^4.12.0

### Form & Data Management
- react-hook-form: ^7.49.0
- @tanstack/react-query: ^5.0.0
- zod: ^3.22.0

## Project Structure
```
muslimhelpgaza/
├── src/
│   ├── components/     # UI components
│   ├── pages/         # Next.js pages
│   ├── lib/           # Utilities
│   ├── styles/        # Styling
│   └── types/         # TypeScript types
├── prisma/
│   └── schema.prisma  # Database schema
├── public/           # Static files & images
└── create-admin.js   # Admin user creation script
```

## Development Commands

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Run linter
npm run lint

# Database commands
npx prisma generate    # Generate client
npx prisma db push     # Push schema changes
```

## Security Features
- Secure authentication with NextAuth.js
- Password hashing with bcrypt
- JWT token-based sessions
- Role-based access control
- Input validation and sanitization
- CSRF protection
- Secure HTTP headers

## Contributing
1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License
Copyright © 2024 Let's Encode. All rights reserved.

## Support
For support, please contact:
- Email: your-support-email@domain.com
- GitHub Issues: [Create an issue](https://github.com/yourusername/muslimhelpgaza/issues)

## Deployment Instructions for muslimhelpgaza.com

### Server Details
- Control Panel: http://142.132.223.45:2082/
- Home Directory: `/home/muslimhe`
- Domain: www.muslimhelpgaza.com
- Username: muslimhe
- Password: 4a]2QiPRQk2e8@

### Admin Panel Access
- URL: https://www.muslimhelpgaza.com/admin
- Email: admin@muslimhelpgaza.com
- Password: Admin@123

### Prerequisites
- Node.js 14+ (via cPanel Node.js Selector)
- MariaDB database (provided by cPanel)
- SSH access to the server

### Step 1: Database Setup in cPanel
1. Log in to cPanel at http://142.132.223.45:2082/
2. Go to "MySQL Database Wizard"
3. Create a new database named `muslimhe_gaza`
4. Create a database user and assign all privileges
5. Note down the database credentials

### Step 2: Upload Project Files
1. Download the deployment package `muslimhelpgaza_deploy.zip`
2. Extract it locally
3. Upload the contents to `/home/muslimhe/public_html` using:
   - cPanel File Manager, or
   - FTP client, or
   - SSH command:
     ```bash
     cd /home/muslimhe
     git clone https://github.com/iammaksudul/muslimhelpgaz.git public_html
     ```

### Step 3: Environment Setup
1. Connect via SSH:
   ```bash
   ssh muslimhe@142.132.223.45
   ```
2. Navigate to project directory:
   ```bash
   cd /home/muslimhe/public_html
   ```
3. Create and configure `.env`:
   ```bash
   cp .env.example .env
   nano .env
   ```
4. Update the following in `.env`:
   ```
   DATABASE_URL="mysql://muslimhe_dbuser:your-password@localhost:3306/muslimhe_gaza"
   NEXTAUTH_URL="https://www.muslimhelpgaza.com"
   NEXTAUTH_SECRET="generate-a-secure-random-string"
   NODE_ENV="production"
   ```

### Step 4: Installation
1. Install dependencies:
   ```bash
   npm install
   ```
2. Generate Prisma client:
   ```bash
   npx prisma generate
   ```
3. Push database schema:
   ```bash
   npx prisma db push
   ```
4. Build the application:
   ```bash
   npm run build
   ```
5. Create admin user:
   ```bash
   node create-admin.js
   ```

### Step 5: Configure Node.js App
1. In cPanel, go to "Setup Node.js App"
2. Create a new application:
   - Application Root: `/home/muslimhe/public_html`
   - Application URL: https://www.muslimhelpgaza.com
   - Application Startup File: `server.js`
   - Node.js Version: 14.x or higher
   - Environment Variables: Copy from your `.env` file

### Step 6: Set File Permissions
```bash
find /home/muslimhe/public_html -type d -exec chmod 755 {} \;
find /home/muslimhe/public_html -type f -exec chmod 644 {} \;
chmod +x /home/muslimhe/public_html/*.sh
```

### Step 7: SSL Configuration
1. In cPanel, go to "SSL/TLS Status"
2. Install AutoSSL certificate for www.muslimhelpgaza.com

### Post-Deployment
1. Access admin panel at: https://www.muslimhelpgaza.com/admin
2. Login with:
   - Email: admin@muslimhelpgaza.com
   - Password: Admin@123
3. **IMPORTANT**: Change admin password immediately after first login

### Troubleshooting
- If you encounter permission errors, contact your hosting provider
- For database connection issues, verify credentials in `.env`
- Check Node.js application logs in cPanel
- Ensure all ports are open and properly configured

### Maintenance
- Regular backups via cPanel Backup Wizard
- Monitor disk space and database size
- Keep Node.js version updated
- Check error logs regularly 