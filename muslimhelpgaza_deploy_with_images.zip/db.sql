-- MySQL dump for Muslim Help Gaza Platform
-- Version: 1.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- Database: `muslimhelpgaza`

CREATE TABLE `users` (
  `id` varchar(191) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('USER','ADMIN') NOT NULL DEFAULT 'USER',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_key` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `donations` (
  `id` varchar(191) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'USD',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text,
  `status` enum('PENDING','COMPLETED','FAILED') NOT NULL DEFAULT 'PENDING',
  `paymentIntent` varchar(255) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `donations_userId_fkey` (`userId`),
  CONSTRAINT `donations_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `content` (
  `id` varchar(191) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `type` enum('text','image','html') NOT NULL DEFAULT 'text',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_key_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `social_links` (
  `id` varchar(191) NOT NULL,
  `platform` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert initial admin user
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `createdAt`, `updatedAt`) VALUES
('clm1234567890', 'Admin User', 'admin@muslimhelpgaza.com', '$2a$10$YourHashedPasswordHere', 'ADMIN', NOW(), NOW());

-- Insert initial content
INSERT INTO `content` (`id`, `key`, `value`, `type`, `createdAt`, `updatedAt`) VALUES
('cls1', 'stripePublicKey', '', 'text', NOW(), NOW()),
('cls2', 'stripeSecretKey', '', 'text', NOW(), NOW()),
('cls3', 'stripeWebhookSecret', '', 'text', NOW(), NOW()),
('cls4', 'currency', 'USD', 'text', NOW(), NOW()),
('cls5', 'monthlyDonationEnabled', 'true', 'text', NOW(), NOW());

-- Insert initial social links
INSERT INTO `social_links` (`id`, `platform`, `url`, `icon`, `createdAt`, `updatedAt`) VALUES
('sl1', 'Facebook', 'https://facebook.com/muslimhelpgaza', 'facebook', NOW(), NOW()),
('sl2', 'Instagram', 'https://instagram.com/muslimhelpgaza', 'instagram', NOW(), NOW());

COMMIT; 