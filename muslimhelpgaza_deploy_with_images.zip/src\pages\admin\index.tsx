import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { signIn, useSession } from 'next-auth/react';
import AdminLayout from '@/components/admin/AdminLayout';
import DashboardStats from '@/components/admin/DashboardStats';
import { AdminGuard } from '@/components/auth/AdminGuard';

const AdminDashboard = () => {
  const { data: session, status } = useSession();
  const router = useRouter();

  if (status === 'loading') {
    return <div>Loading...</div>;
  }

  return (
    <AdminGuard>
      <AdminLayout>
        <div className="p-6">
          <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>
          <DashboardStats />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
            {/* Quick Actions */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
              <div className="space-y-2">
                <button 
                  onClick={() => router.push('/admin/content')}
                  className="w-full text-left px-4 py-2 hover:bg-gray-50 rounded"
                >
                  📝 Edit Content
                </button>
                <button 
                  onClick={() => router.push('/admin/donations')}
                  className="w-full text-left px-4 py-2 hover:bg-gray-50 rounded"
                >
                  💰 Manage Donations
                </button>
                <button 
                  onClick={() => router.push('/admin/users')}
                  className="w-full text-left px-4 py-2 hover:bg-gray-50 rounded"
                >
                  👥 Manage Users
                </button>
                <button 
                  onClick={() => router.push('/admin/settings')}
                  className="w-full text-left px-4 py-2 hover:bg-gray-50 rounded"
                >
                  ⚙️ Settings
                </button>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-semibold mb-4">Recent Activity</h2>
              <div className="space-y-4">
                {/* We'll populate this with real data later */}
                <p className="text-sm text-gray-600">Loading recent activity...</p>
              </div>
            </div>

            {/* System Status */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-semibold mb-4">System Status</h2>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span>Payment System</span>
                  <span className="text-green-500">●</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Email Service</span>
                  <span className="text-green-500">●</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Database</span>
                  <span className="text-green-500">●</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </AdminLayout>
    </AdminGuard>
  );
};

export default AdminDashboard; 