import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import formidable from 'formidable';
import { createWriteStream, mkdir } from 'fs';
import { join } from 'path';
import { promisify } from 'util';

const mkdirAsync = promisify(mkdir);

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const session = await getServerSession(req, res, authOptions);
  if (!session || session.user.role !== 'ADMIN') {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const uploadDir = join(process.cwd(), 'public', 'uploads');
    await mkdirAsync(uploadDir, { recursive: true });

    const form = formidable({
      uploadDir,
      keepExtensions: true,
      maxFiles: 5,
      maxFileSize: 5 * 1024 * 1024, // 5MB
    });

    const [fields, files] = await new Promise((resolve, reject) => {
      form.parse(req, (err, fields, files) => {
        if (err) reject(err);
        resolve([fields, files]);
      });
    });

    const uploadedFiles = Array.isArray(files.files) ? files.files : [files.files];
    const savedFiles = [];

    for (const file of uploadedFiles) {
      if (!file) continue;

      const media = await prisma.media.create({
        data: {
          name: file.originalFilename || file.newFilename,
          url: `/uploads/${file.newFilename}`,
          mimeType: file.mimetype || 'application/octet-stream',
          size: file.size,
          userId: session.user.id,
        },
      });

      savedFiles.push({
        id: media.id,
        name: media.name,
        url: media.url,
        createdAt: media.createdAt,
      });
    }

    res.status(200).json(savedFiles);
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: 'Upload failed' });
  }
} 