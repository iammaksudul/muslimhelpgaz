import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { XMarkIcon } from '@heroicons/react/24/outline';
import Image from 'next/image';

interface DonationPopupProps {
  onClose: () => void;
}

export const DonationPopup = ({ onClose }: DonationPopupProps) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Show popup after 3 seconds
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  if (!isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center"
      >
        {/* Backdrop */}
        <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />

        {/* Modal */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="relative bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4"
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-400 hover:text-gray-500"
          >
            <XMarkIcon className="h-6 w-6" />
          </button>

          {/* Image */}
          <div className="p-6">
            <div className="mb-6">
              <Image
                src="/images/gaza/donation-popup.jpg"
                alt="Gaza families in need"
                width={960}
                height={540}
                className="rounded-lg"
              />
            </div>
          </div>

          {/* Content */}
          <div className="p-6 text-center">
            <h2 className="text-2xl font-bold mb-4">
              Wait! The Prophet ﷺ said:
            </h2>
            <p className="text-lg mb-6">
              <strong>
                "Whoever is pleased for Allah to save him from distress on the Day of
                Resurrection, let him relieve one in hardship or lift his burden."
                (Muslim)
              </strong>{" "}
              Families in Palestine need you right now. Your donation is our Amana.
            </p>
            <a
              href="https://donor.muslimi.com/-/XPBDJYTW"
              className="inline-block bg-red-600 text-white text-xl font-bold py-3 px-8 rounded-full hover:bg-red-700 transition-colors"
            >
              Donate now
            </a>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}; 