import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface Donation {
  id: string;
  name: string;
  amount: number;
  currency: string;
  location: string;
  countryCode: string;
  timestamp: Date;
}

// Sample data for recent donations
const sampleDonations: Donation[] = [
  {
    id: '1',
    name: 'Rauf S.',
    amount: 67.00,
    currency: 'USD',
    location: 'United States',
    countryCode: 'US',
    timestamp: new Date()
  },
  {
    id: '2',
    name: 'Abdul Subhan M.',
    amount: 11.80,
    currency: 'USD',
    location: 'Kuala Lumpur, Malaysia',
    countryCode: 'MY',
    timestamp: new Date(Date.now() - 43 * 60000)
  },
  {
    id: '3',
    name: 'Amir H.',
    amount: 10.62,
    currency: 'USD',
    location: 'London, United Kingdom',
    countryCode: 'GB',
    timestamp: new Date(Date.now() - 55 * 60000)
  },
  {
    id: '4',
    name: 'Mohamed T.',
    amount: 16.89,
    currency: 'USD',
    location: 'Dubai, United Arab Emirates',
    countryCode: 'AE',
    timestamp: new Date(Date.now() - 120 * 60000)
  }
];

const formatTimeAgo = (date: Date) => {
  const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
  
  if (seconds < 60) {
    return 'Just now';
  }
  
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) {
    return `${minutes} minute${minutes === 1 ? '' : 's'} ago`;
  }
  
  const hours = Math.floor(minutes / 60);
  if (hours < 24) {
    return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  }
  
  const days = Math.floor(hours / 24);
  return `${days} day${days === 1 ? '' : 's'} ago`;
};

export const RecentDonations = () => {
  const [isVisible, setIsVisible] = useState(true);
  const [currentDonation, setCurrentDonation] = useState(0);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    // Rotate through donations every 5 seconds
    const interval = setInterval(() => {
      setCurrentDonation((prev) => (prev + 1) % sampleDonations.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  if (!isVisible || !mounted) return null;

  const donation = sampleDonations[currentDonation];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 50 }}
        className="fixed bottom-4 right-4 bg-white rounded-lg shadow-lg p-4 max-w-sm z-50"
      >
        <button
          onClick={() => setIsVisible(false)}
          className="absolute -top-2 -right-2 bg-gray-200 rounded-full p-1 hover:bg-gray-300"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-4 w-4"
            viewBox="0 0 20 20"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
              clipRule="evenodd"
            />
          </svg>
        </button>
        <div className="flex items-center space-x-4">
          <img
            src={`https://flagcdn.com/32x24/${donation.countryCode.toLowerCase()}.png`}
            alt={donation.location}
            className="w-8 h-6 object-cover rounded"
          />
          <div>
            <div className="font-medium">{donation.name}</div>
            <div className="text-sm text-gray-600">{donation.location}</div>
            <div className="text-primary font-bold">
              ${donation.amount.toFixed(2)} {donation.currency}
            </div>
            <div className="text-xs text-gray-500">
              {formatTimeAgo(donation.timestamp)}
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}; 