const { PrismaClient } = require('@prisma/client');
const { hash } = require('bcryptjs');

const prisma = new PrismaClient({
  datasources: {
    db: {
      url: 'file:./dev.db'
    },
  },
});

async function main() {
  const password = await hash('admin123', 12);
  
  const admin = await prisma.user.upsert({
    where: { email: 'admin@muslimhelpgaza.com' },
    update: {},
    create: {
      email: 'admin@muslimhelpgaza.com',
      name: 'Admin',
      password,
      role: 'ADMIN',
    },
  });
  
  console.log('Admin user created:', admin);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  }); 