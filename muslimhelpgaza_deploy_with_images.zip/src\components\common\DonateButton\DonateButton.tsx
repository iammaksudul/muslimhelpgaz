import React, { useState } from 'react';
import { DonationForm } from '../../donation/DonationForm/DonationForm';

export const DonateButton = () => {
  const [showDonationForm, setShowDonationForm] = useState(false);

  return (
    <>
      <button
        className="btn-primary flex items-center space-x-2"
        onClick={() => setShowDonationForm(true)}
      >
        <span>Donate Now</span>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={1.5}
          stroke="currentColor"
          className="w-5 h-5"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12Z"
          />
        </svg>
      </button>

      {/* Modal */}
      {showDonationForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="relative w-full max-w-2xl mx-4">
            <button
              onClick={() => setShowDonationForm(false)}
              className="absolute -top-10 right-0 text-white hover:text-gray-300"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
            <DonationForm onClose={() => setShowDonationForm(false)} />
          </div>
        </div>
      )}
    </>
  );
}; 