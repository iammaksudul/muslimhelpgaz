import React from 'react';
import Image from 'next/image';
import { DonateButton } from '../../common/DonateButton/DonateButton';

const Hero = () => {
  return (
    <section className="relative min-h-[80vh] flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/hero-bg.jpg"
          alt="Gaza Relief"
          fill
          className="object-cover brightness-50"
          priority
        />
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 relative z-10 text-white">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-6">
            Bring Relief & Hope to Families in Gaza
          </h1>
          <p className="text-lg md:text-xl mb-8 opacity-90">
            Your generosity can bring urgent relief to Gaza—Humaniti is on the ground because of you.
          </p>
          
          {/* Impact Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
            <div className="text-center">
              <div className="text-2xl font-bold mb-2">800,000+</div>
              <div className="text-sm opacity-80">Meals Distributed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold mb-2">1M+</div>
              <div className="text-sm opacity-80">People Helped</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold mb-2">50,000+</div>
              <div className="text-sm opacity-80">Medical Aid</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold mb-2">10,000+</div>
              <div className="text-sm opacity-80">Shelters Provided</div>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <DonateButton />
            <button className="btn-secondary">
              Learn More
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero; 