import React from 'react';
import { motion } from 'framer-motion';

interface TopDonor {
  id: string;
  name: string;
  amount: number;
  location: string;
  countryCode: string;
}

const topDonors: TopDonor[] = [
  {
    id: '1',
    name: 'Anonymous',
    amount: 5000,
    location: 'United States',
    countryCode: 'US'
  },
  {
    id: '2',
    name: 'Sarah M.',
    amount: 3500,
    location: 'United Kingdom',
    countryCode: 'GB'
  },
  {
    id: '3',
    name: 'Ahmed K.',
    amount: 2800,
    location: 'United Arab Emirates',
    countryCode: 'AE'
  },
  {
    id: '4',
    name: 'Fatima R.',
    amount: 2500,
    location: 'Canada',
    countryCode: 'CA'
  },
  {
    id: '5',
    name: 'Mohammad S.',
    amount: 2000,
    location: 'Australia',
    countryCode: 'AU'
  }
];

export const TopSupporters = () => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h3 className="text-xl font-bold mb-6">Top Supporters</h3>
      <div className="space-y-4">
        {topDonors.map((donor, index) => (
          <motion.div
            key={donor.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
          >
            <div className="flex items-center space-x-4">
              <div className="flex-shrink-0 w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                <span className="text-primary font-bold">#{index + 1}</span>
              </div>
              <div>
                <div className="font-medium">{donor.name}</div>
                <div className="flex items-center text-sm text-gray-500">
                  <img
                    src={`https://flagcdn.com/16x12/${donor.countryCode.toLowerCase()}.png`}
                    alt={donor.location}
                    className="w-4 h-3 mr-1"
                  />
                  {donor.location}
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="font-bold text-primary">${donor.amount.toLocaleString()}</div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}; 