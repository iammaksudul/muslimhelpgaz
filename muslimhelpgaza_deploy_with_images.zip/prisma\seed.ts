import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  // Create admin user
  const hashedPassword = await bcrypt.hash('admin123', 10);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@muslimhelpgaza.com' },
    update: {},
    create: {
      email: 'admin@muslimhelpgaza.com',
      name: 'Admin',
      password: hashedPassword,
      role: 'ADMIN',
    },
  });

  // Set default payment settings
  const paymentSettings = [
    { key: 'STRIPE_PUBLIC_KEY', value: '' },
    { key: 'STRIPE_SECRET_KEY', value: '' },
    { key: 'STRIPE_WEBHOOK_SECRET', value: '' },
    { key: 'CURRENCY', value: 'USD' },
    { key: 'ENABLE_MONTHLY_DONATIONS', value: 'true' },
  ];

  for (const setting of paymentSettings) {
    await prisma.content.upsert({
      where: { key: setting.key },
      update: { value: setting.value },
      create: { key: setting.key, value: setting.value },
    });
  }

  console.log('Database seeded successfully');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  }); 