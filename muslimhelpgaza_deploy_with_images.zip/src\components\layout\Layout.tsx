import React, { useState } from 'react';
import Header from '../common/Header/Header';
import { DonationPopup } from '../donation/DonationPopup/DonationPopup';
import { Footer } from '../Footer/Footer';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout = ({ children }: LayoutProps) => {
  const [showDonationPopup, setShowDonationPopup] = useState(true);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="pt-20 flex-grow">
        {children}
      </main>
      {showDonationPopup && (
        <DonationPopup onClose={() => setShowDonationPopup(false)} />
      )}
      <Footer />
    </div>
  );
}; 