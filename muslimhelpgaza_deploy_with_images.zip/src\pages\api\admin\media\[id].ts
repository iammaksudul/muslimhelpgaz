import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { unlink } from 'fs/promises';
import { join } from 'path';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'DELETE') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const session = await getServerSession(req, res, authOptions);
  if (!session || session.user.role !== 'ADMIN') {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { id } = req.query;

  try {
    const media = await prisma.media.findUnique({
      where: { id: id as string },
    });

    if (!media) {
      return res.status(404).json({ error: 'Media not found' });
    }

    // Delete the file from the filesystem
    const filePath = join(process.cwd(), 'public', media.url);
    await unlink(filePath);

    // Delete the database record
    await prisma.media.delete({
      where: { id: id as string },
    });

    res.status(200).json({ message: 'Media deleted successfully' });
  } catch (error) {
    console.error('Delete error:', error);
    res.status(500).json({ error: 'Failed to delete media' });
  }
} 