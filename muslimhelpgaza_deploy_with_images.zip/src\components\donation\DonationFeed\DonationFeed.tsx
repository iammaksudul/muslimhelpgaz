import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface Donation {
  id: string;
  name: string;
  amount: number;
  currency: string;
  location: string;
  timestamp: Date;
  countryCode: string;
}

export const DonationFeed = () => {
  const [donations, setDonations] = useState<Donation[]>([
    {
      id: '1',
      name: 'Madiha A.',
      amount: 12.50,
      currency: 'USD',
      location: 'Toronto, Canada',
      timestamp: new Date(),
      countryCode: 'CA'
    },
    {
      id: '2',
      name: 'Kayla G.',
      amount: 28.80,
      currency: 'USD',
      location: 'Chicago, United States',
      timestamp: new Date(Date.now() - 5 * 60000),
      countryCode: 'US'
    },
    // Add more initial donations
  ]);

  const formatTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 60) return 'just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} minutes ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hours ago`;
    return '1 day ago';
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 max-w-md w-full">
      <h3 className="text-xl font-bold mb-4">Recent Donations</h3>
      <div className="space-y-4">
        <AnimatePresence>
          {donations.map((donation) => (
            <motion.div
              key={donation.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -100 }}
              className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                <img
                  src={`https://flagcdn.com/24x18/${donation.countryCode.toLowerCase()}.png`}
                  alt={donation.location}
                  className="w-6 h-4 object-cover rounded"
                />
                <div>
                  <div className="font-medium">{donation.name}</div>
                  <div className="text-sm text-gray-500">{donation.location}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-bold text-primary">
                  ${donation.amount.toFixed(2)} {donation.currency}
                </div>
                <div className="text-xs text-gray-500">
                  {formatTimeAgo(donation.timestamp)}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}; 