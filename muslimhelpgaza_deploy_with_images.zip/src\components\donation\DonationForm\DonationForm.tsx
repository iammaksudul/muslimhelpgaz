import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface DonationAmount {
  value: number;
  label: string;
  description: string;
}

const predefinedAmounts: DonationAmount[] = [
  { value: 75, label: '15 Hot Meals', description: 'Feed 15 people in need' },
  { value: 100, label: 'Emergency Food Pack', description: 'Provide essential food supplies' },
  { value: 125, label: 'Clean Drinking Water', description: 'Supply clean water to families' },
  { value: 200, label: 'Medical Supplies', description: 'Deliver crucial medical aid' },
  { value: 500, label: 'Emergency Shelter', description: 'Provide shelter to displaced families' },
  { value: 1000, label: 'Emergency Aid Combo', description: 'Comprehensive aid package' },
];

interface DonationFormProps {
  onClose: () => void;
}

export const DonationForm = ({ onClose }: DonationFormProps) => {
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [currency, setCurrency] = useState<string>('USD');
  const [isRecurring, setIsRecurring] = useState<boolean>(false);

  const handleCustomAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9.]/g, '');
    setCustomAmount(value);
    setSelectedAmount(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = selectedAmount || Number(customAmount);
    
    // TODO: Implement payment processing
    console.log('Processing donation:', {
      amount,
      currency,
      isRecurring
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Make a Donation</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Currency Selection */}
        <div className="flex justify-end mb-4">
          <select
            value={currency}
            onChange={(e) => setCurrency(e.target.value)}
            className="border rounded-md px-3 py-1"
          >
            <option value="USD">USD ($)</option>
            <option value="EUR">EUR (€)</option>
            <option value="GBP">GBP (£)</option>
            <option value="CAD">CAD ($)</option>
          </select>
        </div>

        {/* Predefined Amounts */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {predefinedAmounts.map((amount) => (
            <motion.button
              key={amount.value}
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => {
                setSelectedAmount(amount.value);
                setCustomAmount('');
              }}
              className={`p-4 rounded-lg border-2 text-left ${
                selectedAmount === amount.value
                  ? 'border-primary bg-primary/5'
                  : 'border-gray-200 hover:border-primary/50'
              }`}
            >
              <div className="font-bold text-xl">${amount.value}</div>
              <div className="font-medium text-primary">{amount.label}</div>
              <div className="text-sm text-gray-500">{amount.description}</div>
            </motion.button>
          ))}
        </div>

        {/* Custom Amount */}
        <div className="relative">
          <input
            type="text"
            value={customAmount}
            onChange={handleCustomAmountChange}
            placeholder="Enter custom amount"
            className="w-full px-4 py-2 border-2 rounded-lg focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none"
          />
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
        </div>

        {/* Recurring Donation */}
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="recurring"
            checked={isRecurring}
            onChange={(e) => setIsRecurring(e.target.checked)}
            className="rounded text-primary focus:ring-primary"
          />
          <label htmlFor="recurring" className="text-gray-700">
            Make this a monthly donation
          </label>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          className="w-full btn-primary py-3 text-lg font-medium"
          disabled={!selectedAmount && !customAmount}
        >
          Donate ${selectedAmount || customAmount || '0'} {currency}
        </button>

        {/* Secure Payment Notice */}
        <div className="text-center text-sm text-gray-500">
          <div className="flex items-center justify-center space-x-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-4 w-4"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z"
                clipRule="evenodd"
              />
            </svg>
            <span>Secure payment processing</span>
          </div>
          <div className="mt-1">Your financial information is encrypted and secure</div>
        </div>
      </form>
    </div>
  );
}; 