import { NextApiRequest, NextApiResponse } from 'next';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  // Only allow in development
  if (process.env.NODE_ENV !== 'development') {
    return res.status(404).json({ error: 'Not found' });
  }

  // Check if NEXTAUTH_SECRET is set
  const hasNextAuthSecret = !!process.env.NEXTAUTH_SECRET;
  
  // Check database connection
  const hasDatabaseUrl = !!process.env.DATABASE_URL;
  
  return res.status(200).json({
    hasNextAuthSecret,
    hasDatabaseUrl,
    nodeEnv: process.env.NODE_ENV,
    // Don't expose the actual secret value
  });
} 