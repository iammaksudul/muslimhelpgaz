import React from 'react';
import Head from 'next/head';
import { VideoSection } from '../components/home/VideoSection/VideoSection';
import { ImpactStats } from '../components/home/ImpactStats/ImpactStats';
import { CampaignUpdates } from '../components/home/CampaignUpdates/CampaignUpdates';
import { Partners } from '../components/home/Partners/Partners';
import { FAQ } from '../components/home/FAQ/FAQ';
import { InteractiveElements } from '../components/home/InteractiveElements/InteractiveElements';
import { ImpactSection } from '../components/home/ImpactSection/ImpactSection';
import { Layout } from '../components/layout/Layout';

export default function Home() {
  return (
    <Layout>
      <Head>
        <title>Muslim Help Gaza - Bringing Relief & Hope</title>
        <meta name="description" content="Support urgent relief efforts in Gaza. Provide food, water, medical aid, and shelter to families in need." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main>
        <section id="home">
          <VideoSection />
        </section>
        
        <section id="statistics">
          <ImpactStats 
            stats={[
              { number: "50,021+", label: "Lives Lost", icon: "⚠️" },
              { number: "116,343+", label: "Wounded", icon: "🏥" },
              { number: "1.1M+", label: "Facing Food Insecurity", icon: "🍞" },
              { number: "800,000+", label: "Hot Meals Distributed", icon: "🍲" }
            ]}
            hadiths={[
              { text: "The best of you are those who feed others.", source: "Ahmad" },
              { text: "Whoever relieves the hardship of a believer in this world, Allah will relieve their hardship on the Day of Judgment.", source: "Muslim" },
              { text: "When Allah loves a people, He afflicts them with trials.", source: "Sahih" }
            ]}
          />
        </section>

        <section id="initiatives">
          <ImpactSection 
            initiatives={[
              {
                title: "Mobile Clinics",
                description: "Providing vital medical support and psychosocial care to over 5,000 individuals with no access to functioning hospitals.",
                icon: "🏥"
              },
              {
                title: "Water Well Rehabilitation",
                description: "Rehabilitated water wells providing clean water to over 50,000 individuals at Al Khair and Al Naser.",
                icon: "💧"
              },
              {
                title: "Hot Meals and Medical Aid",
                description: "Served over 150,000 hot meals and delivered food parcels to more than 25,000 households in Deir Al-Balah and Rafah.",
                icon: "🍲"
              },
              {
                title: "100 Family Village",
                description: "A dedicated village in Deir El Balah providing permanent shelter, meals, water, and education facilities for 100 families.",
                icon: "🏠"
              }
            ]}
          />
        </section>

        <section id="donate">
          <InteractiveElements 
            donationOptions={[
              { amount: "$75 USD", description: "Provides 15 Hot Meals", icon: "🍲" },
              { amount: "$100 USD", description: "Emergency Food Pack", icon: "🥫" },
              { amount: "$125 USD", description: "Clean Drinking Water", icon: "💧" },
              { amount: "$200 USD", description: "Emergency Medical Supplies", icon: "🏥" },
              { amount: "$500 USD", description: "Emergency Shelter", icon: "🏠" },
              { amount: "$1,000 USD", description: "Emergency Aid Combo", icon: "📦" }
            ]}
          />
        </section>

        <section id="impact">
          <CampaignUpdates />
        </section>

        <section id="about">
          <Partners />
          <FAQ />
        </section>
      </main>
    </Layout>
  );
} 