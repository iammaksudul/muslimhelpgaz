import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { hash } from 'bcryptjs';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  if (!session || session.user.role !== 'ADMIN') {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { id } = req.query;

  if (req.method === 'GET') {
    try {
      const staff = await prisma.user.findUnique({
        where: { id: id as string },
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          createdAt: true,
        }
      });

      if (!staff) {
        return res.status(404).json({ error: 'Staff member not found' });
      }

      return res.status(200).json(staff);
    } catch (error) {
      console.error('Error fetching staff member:', error);
      return res.status(500).json({ error: 'Failed to fetch staff member' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const { name, email, password, role } = req.body;

      if (!name || !email || !role) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      const existingUser = await prisma.user.findUnique({
        where: { email }
      });

      if (existingUser && existingUser.id !== id) {
        return res.status(400).json({ error: 'Email already exists' });
      }

      const updateData: any = {
        name,
        email,
        role,
      };

      if (password) {
        updateData.password = await hash(password, 12);
      }

      const user = await prisma.user.update({
        where: { id: id as string },
        data: updateData,
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          createdAt: true,
        }
      });

      return res.status(200).json(user);
    } catch (error) {
      console.error('Error updating staff member:', error);
      return res.status(500).json({ error: 'Failed to update staff member' });
    }
  }

  if (req.method === 'DELETE') {
    try {
      const staff = await prisma.user.findUnique({
        where: { id: id as string }
      });

      if (!staff) {
        return res.status(404).json({ error: 'Staff member not found' });
      }

      // Prevent deleting the last admin
      const adminCount = await prisma.user.count({
        where: { role: 'ADMIN' }
      });

      if (staff.role === 'ADMIN' && adminCount <= 1) {
        return res.status(400).json({ error: 'Cannot delete the last admin' });
      }

      await prisma.user.delete({
        where: { id: id as string }
      });

      return res.status(200).json({ message: 'Staff member deleted successfully' });
    } catch (error) {
      console.error('Error deleting staff member:', error);
      return res.status(500).json({ error: 'Failed to delete staff member' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
} 