import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const session = await getServerSession(req, res, authOptions);

  if (!session || session.user.role !== 'ADMIN') {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (req.method === 'GET') {
    try {
      const settings = await prisma.paymentSettings.findFirst();
      return res.status(200).json(settings || {
        stripeEnabled: false,
        stripePublicKey: null,
        stripeSecretKey: null,
        paypalEnabled: false,
        paypalClientId: null,
        paypalSecret: null,
        bKashEnabled: false,
        bKashNumber: null,
        rocketEnabled: false,
        rocketNumber: null,
        currencies: ['USD'],
        defaultCurrency: 'USD'
      });
    } catch (error) {
      console.error('Error fetching payment settings:', error);
      return res.status(500).json({ error: 'Failed to fetch payment settings' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const {
        stripeEnabled,
        stripePublicKey,
        stripeSecretKey,
        paypalEnabled,
        paypalClientId,
        paypalSecret,
        bKashEnabled,
        bKashNumber,
        rocketEnabled,
        rocketNumber,
        currencies,
        defaultCurrency
      } = req.body;

      // Validate currencies
      if (!Array.isArray(currencies) || currencies.length === 0) {
        return res.status(400).json({ error: 'At least one currency must be selected' });
      }

      if (!defaultCurrency || !currencies.includes(defaultCurrency)) {
        return res.status(400).json({ error: 'Default currency must be one of the selected currencies' });
      }

      const settings = await prisma.paymentSettings.upsert({
        where: { id: 1 },
        update: {
          stripeEnabled,
          stripePublicKey,
          stripeSecretKey,
          paypalEnabled,
          paypalClientId,
          paypalSecret,
          bKashEnabled,
          bKashNumber,
          rocketEnabled,
          rocketNumber,
          currencies,
          defaultCurrency
        },
        create: {
          id: 1,
          stripeEnabled,
          stripePublicKey,
          stripeSecretKey,
          paypalEnabled,
          paypalClientId,
          paypalSecret,
          bKashEnabled,
          bKashNumber,
          rocketEnabled,
          rocketNumber,
          currencies,
          defaultCurrency
        }
      });

      return res.status(200).json(settings);
    } catch (error) {
      console.error('Error updating payment settings:', error);
      return res.status(500).json({ error: 'Failed to update payment settings' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
} 