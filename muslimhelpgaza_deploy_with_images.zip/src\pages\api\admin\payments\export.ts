import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { stringify } from 'csv-stringify/sync';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  if (!session || session.user.role !== 'ADMIN') {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (req.method === 'GET') {
    try {
      const { status, startDate, endDate } = req.query;

      const where: any = {};

      if (status && status !== 'all') {
        where.status = status;
      }

      if (startDate || endDate) {
        where.createdAt = {};
        if (startDate) {
          where.createdAt.gte = new Date(startDate as string);
        }
        if (endDate) {
          where.createdAt.lte = new Date(endDate as string);
        }
      }

      const payments = await prisma.donation.findMany({
        where,
        include: {
          user: {
            select: {
              name: true,
              email: true,
            },
          },
        },
        orderBy: {
          createdAt: 'desc',
        },
      });

      const csvData = payments.map((payment) => ({
        ID: payment.id,
        Date: payment.createdAt.toISOString().split('T')[0],
        'Donor Name': payment.user?.name || 'Anonymous',
        'Donor Email': payment.user?.email || 'N/A',
        Amount: payment.amount,
        Currency: payment.currency,
        Status: payment.status,
      }));

      const csv = stringify(csvData, {
        header: true,
        columns: ['ID', 'Date', 'Donor Name', 'Donor Email', 'Amount', 'Currency', 'Status'],
      });

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename=payments-${new Date().toISOString().split('T')[0]}.csv`);
      return res.status(200).send(csv);
    } catch (error) {
      console.error('Error exporting payments:', error);
      return res.status(500).json({ error: 'Failed to export payments' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
} 