import React from 'react';

interface Donation {
  name: string;
  amount: number;
  location: string;
  timeAgo: string;
}

interface DonationFeedProps {
  donations: Donation[];
}

export const DonationFeed: React.FC<DonationFeedProps> = ({ donations }) => {
  return (
    <div className="fixed left-4 bottom-20 bg-white rounded-lg shadow-lg p-4 max-w-xs w-full">
      <h3 className="text-lg font-bold mb-4">Recent Donations</h3>
      <div className="space-y-3">
        {donations.map((donation, index) => (
          <div key={index} className="flex items-start space-x-3">
            <div className="flex-1">
              <p className="text-sm font-medium">
                {donation.name} donated ${donation.amount}
              </p>
              <p className="text-xs text-gray-500">
                {donation.location} • {donation.timeAgo}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}; 