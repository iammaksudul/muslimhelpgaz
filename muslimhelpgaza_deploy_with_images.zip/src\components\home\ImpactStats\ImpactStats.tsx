import React from 'react';
import Image from 'next/image';
import Link from 'next/link';

interface DonationOption {
  amount: string;
  description: string;
  icon: string;
}

interface Stat {
  number: string;
  label: string;
  icon: string;
}

interface ImpactStatsProps {
  stats: Stat[];
}

export const ImpactStats: React.FC<ImpactStatsProps> = ({ stats }) => {
  return (
    <div className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-6">Current Crisis in Gaza</h2>
          <p className="text-xl text-gray-700 mb-8">
            The streets of Gaza, once filled with the warmth gatherings, now stand in ruins. 
            The sound of children laughing has been replaced with the echoes of hunger and grief. 
            Families who once shared plates with loved ones now sit in the dark, unsure where their next meal will come from.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {stats.map((stat, index) => (
            <div key={index} className="text-center p-6 bg-gray-50 rounded-lg shadow-sm">
              <div className="text-4xl mb-2">{stat.icon}</div>
              <div className="text-3xl font-bold text-red-600 mb-2">{stat.number}</div>
              <div className="text-gray-600">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="text-center mb-12">
          <p className="text-xl text-gray-700 mb-8">
            At Kamal Adwan Hospital in northern Gaza, the only hospital still operating in the area, 
            was raided and staff were reportedly forced to evacuate to destroyed and non-functional 
            Indonesian Hospital where it is almost impossible to provide any care, while the majority 
            of the staff, stable patients and companions were moved to a nearby location. 
            - <strong>World Health Organization.</strong>
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <Image
              src="/images/gaza/Blue-Dandelion-Photo-Collage-5-.jpg"
              alt="Gaza Crisis"
              width={600}
              height={400}
              className="rounded-lg shadow-lg"
            />
          </div>
          <div>
            <Image
              src="/images/gaza/14.jpg"
              alt="Gaza Crisis"
              width={600}
              height={400}
              className="rounded-lg shadow-lg"
            />
          </div>
        </div>

        <div className="text-center mt-12">
          <h3 className="text-2xl font-bold mb-4">The Prophet ﷺ said:</h3>
          <p className="text-xl italic mb-8">
            "The best of you are those who feed others." (Ahmad)
          </p>
          <Link 
            href="https://donor.muslimi.com/-/XPBDJYTW"
            className="inline-block bg-red-600 text-white text-xl font-bold py-4 px-12 rounded-full hover:bg-red-700 transition-colors"
          >
            DONATE NOW
          </Link>
        </div>
      </div>
    </div>
  );
}; 