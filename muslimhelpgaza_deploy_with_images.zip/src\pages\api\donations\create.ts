import { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import Stripe from 'stripe';
import bcrypt from 'bcryptjs';
import { generatePassword } from '@/lib/utils';
import { sendWelcomeEmail } from '@/lib/email';

const prisma = new PrismaClient();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const {
      amount,
      currency,
      name,
      email,
      isMonthly,
      message,
    } = req.body;

    // Create or get user
    let user = await prisma.user.findUnique({
      where: { email },
    });

    if (!user) {
      const password = generatePassword();
      const hashedPassword = await bcrypt.hash(password, 10);

      user = await prisma.user.create({
        data: {
          email,
          name,
          password: hashedPassword,
          role: 'USER',
        },
      });

      // Send welcome email with credentials
      await sendWelcomeEmail({
        email,
        name,
        password,
      });
    }

    // Create Stripe payment intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // Convert to cents
      currency,
      metadata: {
        name,
        email,
        userId: user.id,
      },
    });

    // Create donation record
    const donation = await prisma.donation.create({
      data: {
        amount,
        currency,
        name,
        email,
        message,
        userId: user.id,
        paymentIntent: paymentIntent.id,
        status: 'PENDING',
      },
    });

    // If monthly donation, create subscription
    if (isMonthly) {
      const customer = await stripe.customers.create({
        email,
        name,
        metadata: {
          userId: user.id,
        },
      });

      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [
          {
            price_data: {
              currency,
              unit_amount: Math.round(amount * 100),
              product_data: {
                name: 'Monthly Donation',
              },
              recurring: {
                interval: 'month',
              },
            },
          },
        ],
        payment_behavior: 'default_incomplete',
        payment_settings: { save_default_payment_method: 'on_subscription' },
        expand: ['latest_invoice.payment_intent'],
      });

      return res.json({
        clientSecret: (subscription.latest_invoice as any).payment_intent.client_secret,
        subscriptionId: subscription.id,
        donationId: donation.id,
      });
    }

    // Return client secret for one-time payment
    res.json({
      clientSecret: paymentIntent.client_secret,
      donationId: donation.id,
    });
  } catch (error) {
    console.error('Error processing donation:', error);
    res.status(500).json({ message: 'Error processing donation' });
  }
} 