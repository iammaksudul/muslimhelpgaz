import React from 'react';
import Image from 'next/image';
import { motion } from 'framer-motion';

interface Partner {
  id: string;
  name: string;
  logo: string;
  description: string;
}

const partners: Partner[] = [
  {
    id: '1',
    name: 'Islamic Relief',
    logo: '/images/partners/islamic-relief.png',
    description: 'Global humanitarian and development organization'
  },
  {
    id: '2',
    name: 'Human Concern International',
    logo: '/images/partners/hci.png',
    description: 'Canadian registered charitable organization'
  },
  {
    id: '3',
    name: 'UNWRA',
    logo: '/images/partners/unwra.png',
    description: 'United Nations Relief and Works Agency'
  },
  {
    id: '4',
    name: 'ICNA Relief',
    logo: '/images/partners/icna.png',
    description: 'Islamic Circle of North America Relief'
  },
  {
    id: '5',
    name: 'IDRF',
    logo: '/images/partners/idrf.png',
    description: 'International Development and Relief Foundation'
  }
];

export const Partners = () => {
  const partners = [
    { name: 'WHO', logo: '/images/partners/who-logo.png' },
    { name: 'UNRWA', logo: '/images/partners/unrwa-logo.png' },
    { name: 'Islamic Relief', logo: '/images/partners/islamic-relief-logo.png' },
    { name: 'Red Crescent', logo: '/images/partners/red-crescent-logo.png' }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">Our Partners</h2>
        <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
          Working together with trusted organizations to maximize our impact and ensure efficient aid delivery.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center">
          {partners.map((partner, index) => (
            <div key={index} className="flex items-center justify-center p-4">
              <div className="relative w-32 h-16">
                <Image
                  src={partner.logo}
                  alt={`${partner.name} Logo`}
                  fill
                  className="object-contain"
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}; 