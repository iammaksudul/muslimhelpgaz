import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { DonationFeed } from '../DonationFeed/DonationFeed';

export const VideoSection = () => {
  const donationAmount = 376888;
  const donationGoal = 500000;
  const donorCount = 9233;
  const progressPercentage = (donationAmount / donationGoal) * 100;

  const recentDonations = [
    {
      name: "Ismail M.",
      amount: 11.50,
      location: "Berkeley, United States",
      timeAgo: "5 minutes ago"
    },
    {
      name: "Fareeda A.",
      amount: 12.22,
      location: "Johannesburg, South Africa",
      timeAgo: "20 minutes ago"
    },
    {
      name: "Asif K.",
      amount: 22.95,
      location: "United Kingdom",
      timeAgo: "23 minutes ago"
    },
    {
      name: "Iman M.",
      amount: 14.45,
      location: "Toronto, Canada",
      timeAgo: "1 hour ago"
    }
  ];

  return (
    <section className="min-h-screen relative bg-gradient-to-b from-[#1a237e] to-[#0d47a1]">
      <div className="absolute inset-0 bg-cover bg-center z-0" style={{
        backgroundImage: "url('/images/backgrounds/night-sky.jpg')",
        opacity: 0.6
      }} />
      
      <div className="relative z-10 max-w-6xl mx-auto px-4 py-12 text-center">
        {/* Logo */}
        <div className="mb-8">
          <Image 
            src="/images/muslimi-whiter-logo.png"
            alt="Humaniti"
            width={200}
            height={60}
            className="mx-auto"
          />
        </div>

        {/* Main Heading */}
        <h2 className="text-4xl md:text-6xl font-bold mb-4 text-white">
          Bring Relief & Hope to Families in Gaza
        </h2>

        <p className="text-xl md:text-2xl mb-6 text-white italic">
          Your generosity can bring urgent relief to Gaza—Humaniti is on the ground because of you.
        </p>

        <div className="mb-8">
          <h3 className="text-2xl md:text-3xl text-yellow-300 font-bold" style={{ fontFamily: 'Caveat, cursive' }}>
            Humaniti's <u>Post</u> Ceasefire Update👇
          </h3>
        </div>

        {/* Video Section */}
        <div className="max-w-4xl mx-auto mb-12">
          <div className="relative w-full" style={{ paddingBottom: '56.25%' }}>
            <iframe
              src="https://player.vimeo.com/video/1068484467?share=copy"
              title="Gaza Crisis Appeal"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="absolute top-0 left-0 w-full h-full rounded-xl"
            />
          </div>
        </div>

        {/* Progress Bar Section */}
        <div className="max-w-3xl mx-auto mb-8">
          <div className="flex justify-between text-white mb-2">
            <span className="text-2xl font-bold">${donationAmount.toLocaleString()} raised</span>
            <span className="text-lg">${donationGoal.toLocaleString()} goal</span>
          </div>
          <div className="h-4 bg-white/20 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-green-400 to-green-500 rounded-full"
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
          <div className="text-white mt-2">
            <span>{donorCount.toLocaleString()} donors</span>
          </div>
        </div>

        {/* Donation Buttons */}
        <div className="flex flex-col md:flex-row gap-4 justify-center max-w-2xl mx-auto mb-8">
          <Link 
            href="https://donor.muslimi.com/-/XPBDJYTW"
            className="bg-red-600 text-white text-xl font-bold py-4 px-16 rounded-full hover:bg-red-700 transition-colors w-full md:w-auto"
          >
            DONATE NOW
          </Link>
          <Link 
            href="https://donor.muslimi.com/-/XCSBHVJA"
            className="bg-white text-[#1f4999] text-xl font-bold py-4 px-16 rounded-full hover:bg-gray-100 transition-colors w-full md:w-auto"
          >
            GIVE ZAKAT
          </Link>
        </div>

        {/* Payment Methods and Info */}
        <div className="flex items-center justify-center gap-4 mb-4">
          <Image 
            src="/images/payments/mastercard.png"
            alt="Mastercard"
            width={40}
            height={25}
          />
          <Image 
            src="/images/payments/visa.png"
            alt="Visa"
            width={40}
            height={25}
          />
        </div>

        <div className="text-white text-center max-w-2xl mx-auto">
          <p className="flex items-center justify-center text-lg mb-2">
            <i className="fas fa-check-circle mr-2"></i>
            <span>Registered Canadian & U.S. Nonprofit</span>
          </p>
          <p className="flex items-center justify-center text-lg mb-4">
            <i className="fas fa-check-circle mr-2"></i>
            <span>100% Zakat-Eligible</span>
          </p>
          <p className="text-sm">
            Humaniti's charitable registration number in Canada is 719676926RR0001CRA, and in the USA they are a 501(c)(3) U.S. Nonprofit with Tax ID 92-3079413.
          </p>
        </div>

        {/* Mosque Silhouette */}
        <div className="absolute bottom-0 left-0 right-0">
          <Image 
            src="/images/backgrounds/mosque-silhouette.png"
            alt="Mosque Silhouette"
            width={1920}
            height={200}
            className="w-full"
          />
        </div>
      </div>

      {/* Floating Donation Button */}
      <Link
        href="https://donor.muslimi.com/-/XPBDJYTW"
        className="fixed top-4 right-4 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors z-50"
      >
        DONATE NOW
      </Link>

      {/* Floating Heart Button */}
      <Link
        href="https://donor.muslimi.com/-/XPBDJYTW"
        className="fixed right-4 bottom-20 bg-red-600 text-white p-3 rounded-full hover:bg-red-700 transition-colors z-50"
      >
        <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
        </svg>
      </Link>

      {/* Donation Feed */}
      <DonationFeed donations={recentDonations} />
    </section>
  );
}; 