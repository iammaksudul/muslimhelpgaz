import { useState } from 'react';
import { useSession } from 'next-auth/react';
import AdminLayout from '@/components/AdminLayout';
import MediaUpload from '@/components/MediaUpload';
import { FiTrash2 } from 'react-icons/fi';
import Image from 'next/image';

interface MediaFile {
  id: string;
  url: string;
  name: string;
  createdAt: string;
}

export default function MediaPage() {
  const { data: session } = useSession();
  const [media, setMedia] = useState<MediaFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  const handleUpload = async (files: File[]) => {
    setIsUploading(true);
    try {
      const formData = new FormData();
      files.forEach(file => {
        formData.append('files', file);
      });

      const response = await fetch('/api/admin/media/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const newMedia = await response.json();
      setMedia(prev => [...prev, ...newMedia]);
    } catch (error) {
      console.error('Upload error:', error);
      // Handle error (show toast notification, etc.)
    } finally {
      setIsUploading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/admin/media/${id}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Delete failed');
      }

      setMedia(prev => prev.filter(item => item.id !== id));
    } catch (error) {
      console.error('Delete error:', error);
      // Handle error (show toast notification, etc.)
    }
  };

  if (!session) {
    return null;
  }

  return (
    <AdminLayout>
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold">Media Library</h1>
        </div>

        <div className="mb-8">
          <MediaUpload
            onUpload={handleUpload}
            maxFiles={5}
            accept={['image/jpeg', 'image/png', 'image/gif']}
            maxSize={5242880} // 5MB
          />
        </div>

        <div className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
          {media.map(file => (
            <div key={file.id} className="relative group">
              <div className="aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-lg bg-gray-200">
                <Image
                  src={file.url}
                  alt={file.name}
                  className="object-cover"
                  fill
                  sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                />
              </div>
              <div className="absolute inset-0 flex items-center justify-center opacity-0 bg-black bg-opacity-50 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => handleDelete(file.id)}
                  className="p-2 bg-red-600 text-white rounded-full hover:bg-red-700 transition-colors"
                >
                  <FiTrash2 className="w-5 h-5" />
                </button>
              </div>
              <p className="mt-2 text-sm text-gray-600 truncate">{file.name}</p>
            </div>
          ))}
        </div>
      </div>
    </AdminLayout>
  );
} 