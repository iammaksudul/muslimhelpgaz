import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  if (!session || session.user.role !== 'ADMIN') {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { code } = req.query;

  if (req.method === 'GET') {
    try {
      const language = await prisma.language.findUnique({
        where: { code: code as string },
      });

      if (!language) {
        return res.status(404).json({ error: 'Language not found' });
      }

      return res.status(200).json(language);
    } catch (error) {
      console.error('Error fetching language:', error);
      return res.status(500).json({ error: 'Failed to fetch language' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const { name, nativeName, direction, isActive } = req.body;

      if (!name || !nativeName) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      if (direction !== 'ltr' && direction !== 'rtl') {
        return res.status(400).json({ error: 'Invalid direction value' });
      }

      const language = await prisma.language.update({
        where: { code: code as string },
        data: {
          name,
          nativeName,
          direction,
          isActive: isActive ?? true,
        },
      });

      return res.status(200).json(language);
    } catch (error) {
      console.error('Error updating language:', error);
      return res.status(500).json({ error: 'Failed to update language' });
    }
  }

  if (req.method === 'DELETE') {
    try {
      const language = await prisma.language.findUnique({
        where: { code: code as string },
      });

      if (!language) {
        return res.status(404).json({ error: 'Language not found' });
      }

      if (language.isDefault) {
        return res.status(400).json({ error: 'Cannot delete default language' });
      }

      await prisma.language.delete({
        where: { code: code as string },
      });

      return res.status(200).json({ message: 'Language deleted successfully' });
    } catch (error) {
      console.error('Error deleting language:', error);
      return res.status(500).json({ error: 'Failed to delete language' });
    }
  }

  if (req.method === 'PATCH') {
    try {
      const { isActive } = req.body;

      if (typeof isActive !== 'boolean') {
        return res.status(400).json({ error: 'Invalid status value' });
      }

      const language = await prisma.language.findUnique({
        where: { code: code as string },
      });

      if (!language) {
        return res.status(404).json({ error: 'Language not found' });
      }

      if (language.isDefault && !isActive) {
        return res.status(400).json({ error: 'Cannot deactivate default language' });
      }

      const updatedLanguage = await prisma.language.update({
        where: { code: code as string },
        data: { isActive },
      });

      return res.status(200).json(updatedLanguage);
    } catch (error) {
      console.error('Error updating language status:', error);
      return res.status(500).json({ error: 'Failed to update language status' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
} 