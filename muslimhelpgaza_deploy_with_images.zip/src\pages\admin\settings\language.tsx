import { useState } from 'react';
import { useSession } from 'next-auth/react';
import AdminLayout from '@/components/AdminLayout';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { FiPlus, FiEdit2, FiTrash2, FiCheck, FiX } from 'react-icons/fi';

interface Language {
  code: string;
  name: string;
  nativeName: string;
  isDefault: boolean;
  isActive: boolean;
  direction: 'ltr' | 'rtl';
}

export default function LanguageManagementPage() {
  const { data: session } = useSession();
  const queryClient = useQueryClient();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<Language | null>(null);

  const { data: languages, isLoading } = useQuery<Language[]>({
    queryKey: ['languages'],
    queryFn: async () => {
      const response = await fetch('/api/admin/settings/languages');
      if (!response.ok) {
        throw new Error('Failed to fetch languages');
      }
      return response.json();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (code: string) => {
      const response = await fetch(`/api/admin/settings/languages/${code}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        throw new Error('Failed to delete language');
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['languages'] });
    },
  });

  const toggleActiveMutation = useMutation({
    mutationFn: async ({ code, isActive }: { code: string; isActive: boolean }) => {
      const response = await fetch(`/api/admin/settings/languages/${code}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isActive }),
      });
      if (!response.ok) {
        throw new Error('Failed to update language status');
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['languages'] });
    },
  });

  const setDefaultMutation = useMutation({
    mutationFn: async (code: string) => {
      const response = await fetch(`/api/admin/settings/languages/${code}/default`, {
        method: 'PUT',
      });
      if (!response.ok) {
        throw new Error('Failed to set default language');
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['languages'] });
    },
  });

  const handleDelete = async (code: string) => {
    if (window.confirm('Are you sure you want to delete this language?')) {
      await deleteMutation.mutateAsync(code);
    }
  };

  const handleToggleActive = async (code: string, isActive: boolean) => {
    await toggleActiveMutation.mutateAsync({ code, isActive: !isActive });
  };

  const handleSetDefault = async (code: string) => {
    await setDefaultMutation.mutateAsync(code);
  };

  if (!session) {
    return null;
  }

  return (
    <AdminLayout>
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold">Language Management</h1>
          <button
            onClick={() => setIsModalOpen(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center hover:bg-blue-700 transition-colors"
          >
            <FiPlus className="w-5 h-5 mr-2" />
            Add Language
          </button>
        </div>

        {isLoading ? (
          <div>Loading...</div>
        ) : (
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Language
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Code
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Direction
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Default
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {languages?.map((language) => (
                  <tr key={language.code}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {language.name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {language.nativeName}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {language.code}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {language.direction.toUpperCase()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <button
                        onClick={() => handleToggleActive(language.code, language.isActive)}
                        className={`px-2 py-1 text-xs font-semibold rounded-full ${
                          language.isActive
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {language.isActive ? 'Active' : 'Inactive'}
                      </button>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {language.isDefault ? (
                        <span className="text-green-600">
                          <FiCheck className="w-5 h-5" />
                        </span>
                      ) : (
                        <button
                          onClick={() => handleSetDefault(language.code)}
                          className="text-gray-400 hover:text-gray-600"
                        >
                          Set as Default
                        </button>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => {
                          setSelectedLanguage(language);
                          setIsModalOpen(true);
                        }}
                        className="text-blue-600 hover:text-blue-900 mr-4"
                      >
                        <FiEdit2 className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => handleDelete(language.code)}
                        className="text-red-600 hover:text-red-900"
                        disabled={language.isDefault}
                      >
                        <FiTrash2 className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {isModalOpen && (
          <LanguageModal
            isOpen={isModalOpen}
            onClose={() => {
              setIsModalOpen(false);
              setSelectedLanguage(null);
            }}
            language={selectedLanguage}
          />
        )}
      </div>
    </AdminLayout>
  );
} 