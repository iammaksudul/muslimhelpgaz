import React from 'react';
import Image from 'next/image';
import Link from 'next/link';

interface DonationOption {
  amount: string;
  description: string;
  icon: string;
}

interface InteractiveElementsProps {
  donationOptions: DonationOption[];
}

export const InteractiveElements: React.FC<InteractiveElementsProps> = ({ donationOptions }) => {
  return (
    <div className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-6">Make an Impact Today</h2>
          <p className="text-xl text-gray-700 mb-8">
            Your donation today can bring hope and relief to countless lives in Gaza. 
            In this critical hour, let us come together and show that the Ummah stands 
            unwavering in support of the innocent civilians enduring unimaginable hardships.
          </p>
        </div>

        <div className="space-y-12">
          {/* Hot Meals Section */}
          <div>
            <Image
              src="/images/gaza/Gaza-Hot-meals.jpg"
              alt="Hot Meals for Gaza"
              width={1200}
              height={600}
              className="rounded-lg shadow-lg mb-6"
            />
            <Link 
              href="https://donor.muslimi.com/-/XPBDJYTW"
              className="block w-full bg-red-600 text-white text-2xl font-bold py-4 px-8 rounded-full hover:bg-red-700 transition-colors text-center"
            >
              SHARE A HOT MEAL NOW
            </Link>
          </div>

          {/* Food Parcel Section */}
          <div>
            <Image
              src="/images/gaza/Gaza-Food.jpg"
              alt="Food Parcels for Gaza"
              width={1200}
              height={600}
              className="rounded-lg shadow-lg mb-6"
            />
            <Link 
              href="https://donor.muslimi.com/-/XPBDJYTW"
              className="block w-full bg-red-600 text-white text-2xl font-bold py-4 px-8 rounded-full hover:bg-red-700 transition-colors text-center"
            >
              SHARE A FOOD PARCEL
            </Link>
          </div>

          {/* Clean Water Section */}
          <div>
            <Image
              src="/images/gaza/Gaza-Clean-Water-1-.jpg"
              alt="Clean Water for Gaza"
              width={1200}
              height={600}
              className="rounded-lg shadow-lg mb-6"
            />
            <Link 
              href="https://donor.muslimi.com/-/XPBDJYTW"
              className="block w-full bg-red-600 text-white text-2xl font-bold py-4 px-8 rounded-full hover:bg-red-700 transition-colors text-center"
            >
              GIVE CLEAN WATER
            </Link>
          </div>

          {/* Medical Aid Section */}
          <div>
            <Image
              src="/images/gaza/Gaza-Medical-Aid.jpg"
              alt="Medical Aid for Gaza"
              width={1200}
              height={600}
              className="rounded-lg shadow-lg mb-6"
            />
            <Link 
              href="https://donor.muslimi.com/-/XPBDJYTW"
              className="block w-full bg-red-600 text-white text-2xl font-bold py-4 px-8 rounded-full hover:bg-red-700 transition-colors text-center"
            >
              SEND MEDICAL AID NOW
            </Link>
          </div>

          {/* Shelter Section */}
          <div>
            <Image
              src="/images/gaza/Gaza-Winter-Relief.jpg"
              alt="Winter Relief for Gaza"
              width={1200}
              height={600}
              className="rounded-lg shadow-lg mb-6"
            />
            <Link 
              href="https://donor.muslimi.com/-/XPBDJYTW"
              className="block w-full bg-red-600 text-white text-2xl font-bold py-4 px-8 rounded-full hover:bg-red-700 transition-colors text-center"
            >
              PROVIDE WARMTH & SHELTER
            </Link>
          </div>

          {/* Orphans Section */}
          <div>
            <Image
              src="/images/gaza/Gaza-Orphan.jpg"
              alt="Help Orphans in Gaza"
              width={1200}
              height={600}
              className="rounded-lg shadow-lg mb-6"
            />
            <Link 
              href="https://donor.muslimi.com/-/XPBDJYTW"
              className="block w-full bg-red-600 text-white text-2xl font-bold py-4 px-8 rounded-full hover:bg-red-700 transition-colors text-center"
            >
              SAVE ORPHANS
            </Link>
          </div>
        </div>

        <div className="mt-12 bg-gray-50 p-8 rounded-lg">
          <h3 className="text-2xl font-bold mb-6">Your Donation Makes a Difference</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {donationOptions.map((option, index) => (
              <div key={index} className="flex items-center space-x-3">
                <i className={`fas ${option.icon} text-red-600`}></i>
                <span>{option.amount} = {option.description}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center mt-12">
          <h3 className="text-2xl font-bold mb-4">We Are Humaniti 🤗</h3>
          <p className="text-lg text-gray-700 mb-8">
            At Humanti, change begins with each of us. We're a registered Canadian & American Nonprofit organization. 
            We're driven by the conviction that we can make a difference and have a collective responsibility to end 
            suffering, inequality, and injustice. The suffering of one is the suffering of all, and through small acts, 
            we can eliminate suffering.
          </p>
          <p className="text-lg text-gray-700">
            In a world where people need us, every act counts. We're a united force together bound by a shared humanity. 
            The suffering of any individual affects us all, so we must act.
          </p>
        </div>
      </div>
    </div>
  );
}; 