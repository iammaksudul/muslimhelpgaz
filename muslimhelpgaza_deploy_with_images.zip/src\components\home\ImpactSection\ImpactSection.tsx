import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { RecentDonations } from '../../donation/RecentDonations/RecentDonations';
import { TopSupporters } from '../../donation/TopSupporters/TopSupporters';

const impactStats = [
  { icon: '🍲', value: '75', description: '15 Hot Meals' },
  { icon: '📦', value: '100', description: 'Emergency Food Pack' },
  { icon: '💧', value: '125', description: 'Clean Drinking Water' },
  { icon: '🏥', value: '200', description: 'Medical Supplies' },
  { icon: '🏠', value: '500', description: 'Emergency Shelter' },
  { icon: '🆘', value: '1,000', description: 'Emergency Aid Combo' },
];

interface Initiative {
  title: string;
  description: string;
  icon: string;
}

interface ImpactSectionProps {
  initiatives: Initiative[];
}

const Initiative = ({ title, description, icon }: Initiative) => (
  <div className="bg-white p-6 rounded-lg shadow-md mb-6">
    <div className="flex items-center mb-3">
      <span className="text-2xl mr-2">{icon}</span>
      <h3 className="text-xl font-bold text-gray-800">{title}</h3>
    </div>
    <p className="text-gray-600">{description}</p>
  </div>
);

export const ImpactSection: React.FC<ImpactSectionProps> = ({ initiatives }) => {
  return (
    <div className="bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-6">Current Initiatives by Humaniti on the Ground</h2>
          <p className="text-xl text-gray-700 mb-8">
            From the besieged northern regions of Gaza to the heart of the occupied West Bank, 
            Humaniti's teams are on the ground, delivering life-saving support. Our mission is clear: 
            to reach every family, every child, every individual in need, no matter how difficult the circumstances.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {initiatives.map((initiative, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-3xl mb-4">{initiative.icon}</div>
              <h3 className="text-xl font-bold mb-2">{initiative.title}</h3>
              <p className="text-gray-600">{initiative.description}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div>
            <Image
              src="/images/gaza/13.jpg"
              alt="Gaza Aid"
              width={600}
              height={400}
              className="rounded-lg shadow-lg"
            />
          </div>
          <div>
            <Image
              src="/images/gaza/12.jpg"
              alt="Gaza Aid"
              width={600}
              height={400}
              className="rounded-lg shadow-lg"
            />
          </div>
        </div>

        <div className="text-center mb-12">
          <h3 className="text-2xl font-bold mb-4">The Prophet ﷺ said:</h3>
          <p className="text-xl italic mb-8">
            "Whoever relieves the hardship of a believer in this world, Allah will relieve their hardship on the Day of Judgment." (Muslim)
          </p>
        </div>

        <div className="bg-white p-8 rounded-lg shadow-lg">
          <h3 className="text-2xl font-bold mb-6">Your Donation Makes a Difference</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="flex items-center space-x-3">
              <i className="fas fa-utensils text-red-600"></i>
              <span>$75 USD = 15 Hot Meals</span>
            </div>
            <div className="flex items-center space-x-3">
              <i className="fas fa-box-open text-red-600"></i>
              <span>$100 USD = Emergency Food Pack</span>
            </div>
            <div className="flex items-center space-x-3">
              <i className="fas fa-tint text-red-600"></i>
              <span>$125 USD = Clean Drinking Water</span>
            </div>
            <div className="flex items-center space-x-3">
              <i className="fas fa-briefcase-medical text-red-600"></i>
              <span>$200 USD = Emergency Medical Supplies</span>
            </div>
            <div className="flex items-center space-x-3">
              <i className="fas fa-campground text-red-600"></i>
              <span>$500 USD = Emergency Shelter</span>
            </div>
            <div className="flex items-center space-x-3">
              <i className="fas fa-hands-helping text-red-600"></i>
              <span>$1,000 USD = Emergency Aid Combo</span>
            </div>
          </div>
        </div>

        <div className="text-center mt-12">
          <Link 
            href="https://donor.muslimi.com/-/XPBDJYTW"
            className="inline-block bg-red-600 text-white text-xl font-bold py-4 px-12 rounded-full hover:bg-red-700 transition-colors"
          >
            DONATE NOW
          </Link>
        </div>
      </div>
    </div>
  );
}; 