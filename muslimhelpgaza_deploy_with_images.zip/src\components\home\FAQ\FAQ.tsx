import React, { useState } from 'react';

interface FAQItem {
  question: string;
  answer: string;
}

const faqs: FAQItem[] = [
  {
    question: "How is my donation used to help Gaza?",
    answer: "Your donation directly supports our initiatives in Gaza, including providing hot meals, clean water, medical supplies, and emergency shelter. We work with trusted local partners to ensure efficient aid delivery."
  },
  {
    question: "Is my donation tax-deductible?",
    answer: "Yes, as a registered Canadian & American Nonprofit organization, your donations are tax-deductible. You will receive a tax receipt for your contribution."
  },
  {
    question: "How can I be sure my donation reaches those in need?",
    answer: "We maintain complete transparency in our operations. We work with established local partners and provide regular updates on our aid distribution through our campaign updates section."
  },
  {
    question: "What are the most urgent needs in Gaza right now?",
    answer: "The most urgent needs include food, clean water, medical supplies, and shelter. With over 1.1 million people facing food insecurity and critical shortages of basic necessities, every form of aid is crucial."
  },
  {
    question: "Can I specify how I want my donation to be used?",
    answer: "Yes, you can choose specific donation options such as providing hot meals, emergency food packs, clean water, medical supplies, or shelter. You can select these options when making your donation."
  }
];

const FAQItem = ({ question, answer }: FAQItem) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-gray-200">
      <button
        className="w-full py-4 text-left flex justify-between items-center focus:outline-none"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="font-medium text-gray-900">{question}</span>
        <span className={`transform transition-transform ${isOpen ? 'rotate-180' : ''}`}>
          ▼
        </span>
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ${
          isOpen ? 'max-h-96 pb-4' : 'max-h-0'
        }`}
      >
        <p className="text-gray-600">{answer}</p>
      </div>
    </div>
  );
};

export const FAQ = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-3xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">Frequently Asked Questions</h2>
        <div className="bg-white rounded-lg shadow-md p-6">
          {faqs.map((faq, index) => (
            <FAQItem key={index} {...faq} />
          ))}
        </div>
      </div>
    </section>
  );
}; 