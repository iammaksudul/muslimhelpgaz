import React from 'react';

interface ProgressBarProps {
  raised: number;
  goal: number;
  donors: number;
}

export const ProgressBar = ({ raised, goal, donors }: ProgressBarProps) => {
  const percentage = Math.min((raised / goal) * 100, 100);

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-2">
        <div className="text-3xl md:text-4xl font-bold text-white">
          ${raised.toLocaleString()} <span className="text-lg">raised</span>
        </div>
        <div className="text-xl text-white">
          ${goal.toLocaleString()} goal
        </div>
      </div>
      
      {/* Progress Bar */}
      <div className="relative h-4 bg-white/20 rounded-full overflow-hidden">
        <div 
          className="absolute left-0 top-0 h-full bg-[#4CAF50] transition-all duration-1000"
          style={{ width: `${percentage}%` }}
        />
      </div>
      
      {/* Percentage and Donors */}
      <div className="flex justify-between items-center mt-2">
        <div className="text-lg text-white">
          {percentage.toFixed(0)}%
        </div>
        <div className="text-lg text-white">
          {donors.toLocaleString()} donors
        </div>
      </div>
    </div>
  );
}; 